package com.example.reloj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    int count=0;
    private static final String TAG = "MyActivity";
    JsonObjectRequest  jsonObjectRequest;
    RequestQueue request;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView=(TextView)findViewById(R.id.textView);

        Thread t=new Thread() {
            @Override
            public  void run() {
                while (!isInterrupted()) {

                    try {
                        Thread.sleep(1000); //1000ms = 1 sec

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                count++;
                                if(count%4==0){
                                    Log.i(TAG, "Hola mundo" );

                                }

                                textView.setText(String.valueOf(count));
                            }
                        });


                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }

            }

        };

        t.start();

    }
}